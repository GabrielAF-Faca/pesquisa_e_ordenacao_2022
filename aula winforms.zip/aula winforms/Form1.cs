namespace aula_winforms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void button_gerar_Click(object sender, EventArgs e)
        {
            enable_pannel(false);
            textBox_dados.Clear();

            lista.Clear();
            Random rand = new Random();
            

            try
            {
                long qtdNumeros = long.Parse(textBox_qtdDados.Text);

                Dado dado;

                for (; qtdNumeros > 0; qtdNumeros--)
                {
                    dado = new Dado(rand.Next(0, 10), rand.Next(0, 500));

                    lista.Add( dado );

                    textBox_dados.AppendText(dado.Chave1 + " - " + dado.Chave2 + Environment.NewLine);

                }

                label_qtdLista.Text = "N�meros na lista: " + lista.Count;
                enable_pannel(true);

            } catch (FormatException) {

                MessageBox.Show("Tipo de dados inv�lido na text box", "Alerta");

            } catch (Exception)
            {

                MessageBox.Show("Confira os dados na text box", "Alerta");

            }

            //Limpa os dados da textbox quando clica no bot�o gerar
            textBox_qtdDados.Text = "";

            

        }

        private void enable_pannel(bool enable)
        {

            panel_direita.Enabled = enable;

        }

        List<Dado> lista = new List<Dado>();

        private void button_abrirArquivo_Click(object sender, EventArgs e)
        {
            textBox_dados.Clear();

            lista.Clear();

            enable_pannel(false);

            OpenFileDialog openFile = new OpenFileDialog();

            openFile.InitialDirectory = @"C:\";
            openFile.RestoreDirectory = true;
            openFile.Title = "Selecione o arquivo fonte com os n�meros: ";
            openFile.DefaultExt = ".txt";
            openFile.Filter = "txt files (*.txt)|*.txt";

            Dado dado;

            try
            {
                openFile.ShowDialog();

                string[] linhas = File.ReadAllLines(openFile.FileName);
                string[] numeros;

                for (int i = 0; i < linhas.Length; i++)
                {
                    numeros = linhas[i].Split(";");

                    dado = new Dado(int.Parse(numeros[0]), int.Parse(numeros[1]));
                    lista.Add(dado);

                    textBox_dados.AppendText(dado.Chave1 + " - " + dado.Chave2 + Environment.NewLine);
                }

                label_qtdLista.Text = "N�meros na lista: " + lista.Count;
                enable_pannel(true);

            }
            catch (Exception)
            {
                throw;
            }
            
            

        }

        private void button_aplicar_Click(object sender, EventArgs e)
        {

            switch (textBox_algoritmo.Text.ToUpper())
            {

                case "BOLHA":
                    Ordena.bolha2Chave(lista);
                    exibir_lista(lista);
                    break;



                default:
                    break;

            }
            
            

        }

        private void exibir_lista(List<Dado> lista)
        {

            foreach (Dado dado in lista)
            {
                textBox_console.AppendText(dado.Chave1 + " - " + dado.Chave2 + Environment.NewLine);
            }

        }

        private void button_limpar_Click(object sender, EventArgs e)
        {

            textBox_algoritmo.Clear();
            textBox_console.Clear();
            enable_pannel(false);

        }
    }
}