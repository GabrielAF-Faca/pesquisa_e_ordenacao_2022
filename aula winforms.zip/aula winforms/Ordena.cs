﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula_winforms
{
    public class Ordena
    {

        public static void bolha2Chave(List<Dado> lista)
        {

            int i;
            Dado aux;
            bool houveTroca;

            do
            {

                houveTroca = false;

                for (i = 0; i < lista.Count - 1; i++)
                {

                    if (lista[i].Chave1 > lista[i + 1].Chave1)
                    {
                        houveTroca = true;

                        aux = lista[i];
                        lista[i] = lista[i + 1];
                        lista[i + 1] = aux;

                    } 

                }


            } while ( houveTroca );



        }

    }
}
